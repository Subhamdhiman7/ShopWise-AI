function scrollIfNearBottom() {
  const chatBox = document.getElementById("chat-box");
  const isNearBottom = chatBox.scrollHeight - chatBox.scrollTop - chatBox.clientHeight < 100;

  if (isNearBottom) {
    chatBox.scrollTo({
      top: chatBox.scrollHeight,
      behavior: "smooth"
    });
  }
}

async function sendMessage() {
  const input = document.getElementById("chat-input");
  const message = input.value.trim();
  if (!message) return;

  const chatBox = document.getElementById("chat-box");

  const userMessage = document.createElement("div");
  userMessage.className = "message user";
  userMessage.textContent = `You: ${message}`;
  chatBox.appendChild(userMessage);
  input.value = "";
  input.style.height = "auto";

  const botMessage = document.createElement("div");
  botMessage.className = "message bot-message";
  botMessage.innerHTML = `<span class="bot-icon">🛍️</span><div class="typing-area"></div>`;
  chatBox.appendChild(botMessage);

  try {
    const res = await fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: message })
    });

    if (!res.ok) throw new Error(`Server responded with status: ${res.status}`);

    const data = await res.json();
    const typingArea = botMessage.querySelector(".typing-area");

    const paragraphs = data.reply.split(/\n\s*\n/);
    for (let para of paragraphs) {
      const paraElem = document.createElement("p");
      typingArea.appendChild(paraElem);

      let currentText = '';
      for (let i = 0; i < para.length; i++) {
        currentText += para[i];
        
        if (para.codePointAt(i) > 255) {
          if (currentText.length > 1) {
            paraElem.innerHTML += currentText.slice(0, -1);
          }
          paraElem.innerHTML += para[i];
          currentText = '';
          await new Promise(r => setTimeout(r, 50));
        } else if (para[i] === "\n") {
          paraElem.innerHTML += currentText.replace("\n", "<br>");
          currentText = '';
        }
        
        scrollIfNearBottom();
        await new Promise(r => setTimeout(r, 10));
      }
      
      if (currentText) {
        paraElem.innerHTML += currentText;
      }
      
      await new Promise(r => setTimeout(r, 200));
    }

  } catch (err) {
    console.error("Chat fetch error:", err.message);
    const errorMsg = document.createElement("p");
    errorMsg.innerHTML = "⚠️ Sorry, I couldn't fetch a response. Please try again later.";
    typingArea.appendChild(errorMsg);
  }
}

const chatInput = document.getElementById("chat-input");

chatInput.addEventListener("keydown", function (event) {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});

chatInput.addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = this.scrollHeight + "px";
});

chatInput.addEventListener("focus", () => {
  const chatBox = document.getElementById("chat-box");
  if (chatBox.innerHTML.trim() === "") {
    const hint = document.createElement("div");
    hint.className = "message bot-message";
    hint.innerHTML = `
      <span class="bot-icon">🛍️</span>
      <div class="typing-area">
        <p>Hi! I'm your <strong>Product Review Assistant</strong> 🤖</p>

      </div>
    `;
    chatBox.appendChild(hint);
  }
});

// Vertical emoji bar implementation
document.addEventListener("DOMContentLoaded", () => {
  const emojiBar = document.createElement("div");
  emojiBar.id = "emoji-bar";
  emojiBar.style.position = "fixed";
  emojiBar.style.bottom = "100px";
  emojiBar.style.left = "20px";
  emojiBar.style.display = "flex";
  emojiBar.style.flexDirection = "column";
  emojiBar.style.gap = "5px";
  emojiBar.style.background = "rgba(30,30,30,0.9)";
  emojiBar.style.borderRadius = "15px";
  emojiBar.style.padding = "10px";
  emojiBar.style.zIndex = "100";
  emojiBar.style.boxShadow = "0 4px 12px rgba(0,0,0,0.2)";
  emojiBar.style.border = "1px solid rgba(255,255,255,0.1)";

  const popularEmojis = ["📱 ", "💻 ", "🎧 ", "📺 ", "👟 ", "📷 ", "💰 ", "⭐ "];
  popularEmojis.forEach(emoji => {
    const btn = document.createElement("button");
    btn.textContent = emoji;
    btn.style.fontSize = "18px";
    // btn.style.background = "none";
    btn.style.border = "none";
    btn.style.cursor = "pointer";
    btn.style.width = "40px";
    btn.style.height = "40px";
    btn.style.borderRadius = "50%";
    btn.style.transition = "all 0.2s";
    btn.title = "Click to insert emoji";
    
    btn.onclick = () => {
      document.getElementById("chat-input").value += emoji;
      document.getElementById("chat-input").focus();
    };
    
    btn.onmouseenter = () => {
      btn.style.transform = "scale(1.2)";
      btn.style.background = "rgba(255,255,255,0.1)";
    };
    
    btn.onmouseleave = () => {
      btn.style.transform = "scale(1)";
      btn.style.background = "none";
    };
    
    emojiBar.appendChild(btn);
  });

  // Toggle button for emoji bar
  const toggleBtn = document.createElement("button");
  toggleBtn.textContent = "";
  toggleBtn.style.position = "fixed";
  toggleBtn.style.bottom = "60px";
  toggleBtn.style.left = "20px";
  toggleBtn.style.width = "50px";
  toggleBtn.style.height = "50px";
  toggleBtn.style.borderRadius = "50%";
  toggleBtn.style.background = "#3a3a72";
  toggleBtn.style.color = "white";
  toggleBtn.style.border = "none";
  toggleBtn.style.fontSize = "24px";
  toggleBtn.style.cursor = "pointer";
  toggleBtn.style.zIndex = "101";
  toggleBtn.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
  
  let emojiBarVisible = false;
  emojiBar.style.display = "none";
  
  toggleBtn.onclick = (e) => {
    e.stopPropagation();
    emojiBarVisible = !emojiBarVisible;
    emojiBar.style.display = emojiBarVisible ? "flex" : "none";
    toggleBtn.textContent = emojiBarVisible ? "" : "";
    toggleBtn.style.background = emojiBarVisible ? "#ff4757" : "#3a3a72";
  };
  
  document.body.appendChild(toggleBtn);
  document.body.appendChild(emojiBar);

  // Close emoji bar when clicking outside
  document.addEventListener("click", (e) => {
    if (emojiBarVisible && 
        !emojiBar.contains(e.target) && 
        e.target !== toggleBtn) {
      emojiBarVisible = false;
      emojiBar.style.display = "none";
      toggleBtn.textContent = "";
      toggleBtn.style.background = "#3a3a72";
    }
  });
});