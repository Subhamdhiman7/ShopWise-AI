import sys
import io
import json
import google.generativeai as genai

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def clean_text(text):
    return text.encode('utf-8', 'surrogatepass').decode('utf-8', 'ignore')

genai.configure(api_key="AIzaSyAbz6YqHhQfvjmwd0o78gdv4_GNJliH540")
model = genai.GenerativeModel("models/gemini-1.5-pro-latest")

data = json.loads(sys.stdin.read())
history = data["history"]
last_user_message = history[-1]["content"] if history and history[-1]["role"] == "user" else ""

# Emoji mapping for common product categories
emoji_map = {
    'phone': '📱', 'laptop': '💻', 'tv': '📺', 'camera': '📷',
    'headphone': '🎧', 'watch': '⌚', 'tablet': '📱', 'console': '🎮',
    'refrigerator': '❄️', 'washing': '🧼', 'air conditioner': '❄️',
    'shoes': '👟', 'clothes': '👕', 'bag': '👜', 'jewelry': '💎',
    'book': '📚', 'toy': '🧸', 'furniture': '🛋️', 'tool': '🛠️'
}

# Detect product category for emoji
detected_category = next(
    (emoji_map[key] for key in emoji_map if key in last_user_message.lower()),
    '🛍️'  # default shopping bag emoji
)

is_detailed_query = any(keyword in last_user_message.lower() for keyword in [
    'detail', 'detailed', 'compare', 'pros and cons', 'advantages', 
    'disadvantages', 'explain', 'difference', 'which one', 'help me choose'
])

conversation = f"""🌟 You are an AI shopping assistant {detected_category}. Analyze the user's query and respond appropriately:

📦 For general queries: 1-2 sentences with key points
🔍 For detailed requests: Comprehensive analysis with:
   • Comparisons ↔️  
   • Pros/Cons ✔️❌  
   • Price/value 💰  
   • Recommendations 👍👎

🎯 Response guidelines:
1. Always begin with category emoji + brief summary
2. Use bullet points • for detailed responses
3. Include relevant emojis to highlight:
   - Performance ⚡  
   - Quality ✨  
   - Issues ⚠️  
   - Deals 🎉  
4. End with clear recommendation if appropriate

🚫 Off-topic response: "I specialize in product reviews {detected_category}. Ask me about gadgets, appliances, or shopping advice! 🛒"
"""

for msg in history:
    if msg["role"] == "user":
        conversation += f'\n👤 User: {msg["content"]}'
    else:
        conversation += f'\n🤖 Bot: {msg["content"]}'

if is_detailed_query:
    conversation += f"\n\n[🔎 System Note: User requested detailed analysis. Provide comprehensive response with comparisons, pros/cons, and clear recommendations.]"

conversation = clean_text(conversation)

response = model.generate_content(conversation)
print(response.text)