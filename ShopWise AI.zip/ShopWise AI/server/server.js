const express = require('express');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const app = express();
const PORT = 3000;

// Chat memory initialization
let chatMemory = [];
const MAX_MEMORY_LENGTH = 20; // Keep last 20 messages
// Add this at the top after imports
const cors = require('cors');
app.use(cors()); // This replaces your manual CORS setup

app.use(express.static(path.join(__dirname, '../public')));  // Removed the options object

// Add separate middleware for cache control
app.use((req, res, next) => {
  if (req.path.endsWith('.html')) {
    res.set('Cache-Control', 'no-cache');
  }
  next();
});
// Enhanced CORS configuration
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Credentials', 'true');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));




// Shopping cart initialization
const shoppingCartFile = path.join(__dirname, '../data/shopping_cart.json');
let shoppingCart = {
  items: [],
  totalItems: 0,
  totalCost: 0
};

// Improved cart file handling with retry logic
function initializeCart() {
  const maxRetries = 3;
  let attempts = 0;

  const attemptLoad = () => {
    try {
      // Ensure data directory exists
      if (!fs.existsSync(path.dirname(shoppingCartFile))) {
        fs.mkdirSync(path.dirname(shoppingCartFile), { recursive: true });
      }

      // Load or initialize cart
      if (fs.existsSync(shoppingCartFile)) {
        const rawData = fs.readFileSync(shoppingCartFile, 'utf8');
        if (rawData.trim()) {
          const data = JSON.parse(rawData);
          shoppingCart = {
            items: data.items || [],
            totalItems: data.totalItems || 0,
            totalCost: data.totalCost || 0
          };
          console.log('🛒 Cart loaded successfully');
          return;
        }
      }
      saveCart(); // Create fresh file if doesn't exist
    } catch (err) {
      console.error(`❌ Error initializing cart (attempt ${attempts + 1}):`, err.message);
      attempts++;
      if (attempts < maxRetries) {
        setTimeout(attemptLoad, 100 * attempts);
      } else {
        console.error('❌ Failed to initialize cart after retries');
        saveCart(); // Force create fresh file
      }
    }
  };

  attemptLoad();
}

// Enhanced cart saving with error recovery
function saveCart() {
  try {
    const tempFile = `${shoppingCartFile}.${Date.now()}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(shoppingCart, null, 2), 'utf8');
    
    // Backup existing file if it exists
    if (fs.existsSync(shoppingCartFile)) {
      fs.copyFileSync(shoppingCartFile, `${shoppingCartFile}.bak`);
    }
    
    fs.renameSync(tempFile, shoppingCartFile);
    console.log('💾 Cart saved successfully');
  } catch (err) {
    console.error('❌ Failed to save cart:', err.message);
    // Attempt to recover by writing to alternative location
    const recoveryFile = path.join(__dirname, '../data/recovery_cart.json');
    fs.writeFileSync(recoveryFile, JSON.stringify(shoppingCart, null, 2));
    console.log(`⚠️ Cart data saved to recovery file: ${recoveryFile}`);
  }
}

// Initialize cart on server start
initializeCart();

// Enhanced cart endpoints with better error handling
app.post('/cart/add', (req, res) => {
  try {
    const { productName, price } = req.body;
    
    if (!productName?.trim() || price === undefined || price === '') {
      return res.status(400).json({ 
        success: false,
        error: 'MISSING_FIELDS',
        message: 'Product name and price are required' 
      });
    }

    const numericPrice = parseFloat(price);
    if (isNaN(numericPrice) || numericPrice < 0) {
      return res.status(400).json({ 
        success: false,
        error: 'INVALID_PRICE',
        message: 'Price must be a positive number' 
      });
    }

    const productWithEmoji = addProductEmoji(productName.trim());
    const newItem = { 
      productName: productWithEmoji, 
      price: numericPrice,
      addedAt: new Date().toISOString(),
      id: Date.now().toString() // Add unique ID for each item
    };

    shoppingCart.items.push(newItem);
    shoppingCart.totalItems = shoppingCart.items.length;
    shoppingCart.totalCost = shoppingCart.items.reduce((sum, item) => sum + item.price, 0);
    
    saveCart();

    return res.json({
      success: true,
      message: 'Product added to cart',
      item: newItem,
      cart: shoppingCart
    });

  } catch (err) {
    console.error('❌ Error in /cart/add:', err);
    return res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: 'Internal server error'
    });
  }
});

app.get('/cart', (req, res) => {
  try {
    res.json({
      success: true,
      cart: shoppingCart,
      message: 'Cart retrieved successfully',
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('❌ Error in /cart:', err);
    res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: 'Failed to retrieve cart'
    });
  }
});

app.post('/cart/clear', (req, res) => {
  try {
    shoppingCart = {
      items: [],
      totalItems: 0,
      totalCost: 0
    };
    saveCart();
    res.json({ 
      success: true,
      message: 'Cart cleared successfully',
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('❌ Error in /cart/clear:', err);
    res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: 'Failed to clear cart'
    });
  }
});

// Enhanced product emoji function
function addProductEmoji(name) {
  const emojiMap = {
    phone: '📱', iphone: '📱', samsung: '📱', 
    laptop: '💻', macbook: '💻', dell: '💻',
    tv: '📺', television: '📺', 
    camera: '📷', dslr: '📷',
    headphone: '🎧', airpods: '🎧', 
    watch: '⌚', smartwatch: '⌚',
    tablet: '📱', ipad: '📱',
    console: '🎮', playstation: '🎮', xbox: '🎮',
    // ... (keep your existing emoji mappings)
  };

  const matchedKey = Object.keys(emojiMap).find(key => 
    name.toLowerCase().includes(key)
  );
  
  return matchedKey ? `${emojiMap[matchedKey]} ${name}` : `🛍️ ${name}`;
}

// Enhanced chat endpoint
app.post('/chat', async (req, res) => {
  try {
      const { message } = req.body;
      
      if (!message?.trim()) {
          return res.status(400).json({ 
              success: false,
              error: 'MISSING_MESSAGE',
              message: 'Message is required' 
          });
      }

      // Add to chat memory
      chatMemory.push({ role: "user", content: message.trim() });
      
      // Limit memory size
      if (chatMemory.length > MAX_MEMORY_LENGTH) {
          chatMemory = chatMemory.slice(-MAX_MEMORY_LENGTH);
      }

      const py = spawn('python', [path.join(__dirname, 'chatbot.py')]);
      
      // Write to Python process
      py.stdin.write(JSON.stringify({ 
          history: chatMemory 
      }));
      py.stdin.end();

      let reply = '';
      // Collect data from Python
      py.stdout.on('data', (data) => {
          reply += data.toString();
      });

      // Handle Python errors
      py.stderr.on('data', (data) => {
          console.error('Python Error:', data.toString());
      });

      // Wait for Python process to complete
      const response = await new Promise((resolve, reject) => {
          py.on('close', (code) => {
              if (code !== 0) {
                  return reject(new Error(`Python process exited with code ${code}`));
              }
              resolve(reply.trim());
          });
      });

      if (!response) {
          throw new Error('Empty response from chatbot');
      }

      // Add bot response to memory
      chatMemory.push({ role: "bot", content: response });
      
      return res.json({
          success: true,
          reply: response
      });

  } catch (error) {
      console.error('❌ Chat Error:', error);
      return res.status(500).json({
          success: false,
          error: 'CHAT_ERROR',
          message: error.message || 'Failed to process chat request'
      });
  }
});

// Routes
app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/about.html'));
});

app.get('*', (req, res) => {
  res.status(404).sendFile(path.join(__dirname, '../public/404.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Unhandled error:', err);
  res.status(500).json({
    success: false,
    error: 'UNHANDLED_ERROR',
    message: 'An unexpected error occurred'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📁 Cart data: ${shoppingCartFile}`);
});